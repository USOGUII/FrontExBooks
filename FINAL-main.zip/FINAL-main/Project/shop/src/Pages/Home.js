import React, { Component } from 'react'
import Items from '../Components/Items'
import Header from '../Components/Header'

export default class Home extends React.Component {
  
  render() {
    return (
      <div>
        
      </div>
    )
  }

}
