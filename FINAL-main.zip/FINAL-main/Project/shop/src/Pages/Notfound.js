import React, { Component } from 'react'

export default class Notfound extends Component {
  render() {
    return (
      <div>Notfound(404)</div>
    )
  }
}
